#!/usr/bin/python
# -*- coding: utf-8 -*-

#Version:       0.01
#Create:        2016-03-09
#Authoruis:     kun/
#project:       base.py

class Base():
	
	def __init__(self):
		print 'init Base !'
	
	@staticmethod
	def test():
		print 'Base test is running !'


