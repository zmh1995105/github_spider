#!/usr/bin/python
# -*- coding: utf-8 -*-

#Version:       0.01
#Create:        2016-03-09
#Authoruis:     kun/
#project:	main.py

import sys,os,re

def main():
        base =  __import__(sys.argv[1])#动态加载控制台输入的模块名
        clas = getattr(base, sys.argv[1])#动态获取对象
        clas.test()#调用base中的方法
	print globals()

if __name__ == '__main__':
        main()

