#!/usr/bin/python
# -*- coding: utf-8 -*-

#Version:       0.01
#Create:        2016-03-09
#Authoruis:     kun/
#project:       test.py

from base import Base

class test(Base):
	
	@staticmethod
	def test():
		print 'test test() is run !'
